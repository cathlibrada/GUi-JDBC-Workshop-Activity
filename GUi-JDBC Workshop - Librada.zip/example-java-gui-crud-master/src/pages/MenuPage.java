package pages;

import javax.swing.*;
import java.awt.*;

public class MenuPage extends JFrame {

    public MenuPage() {
        setTitle("Main Menu");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 20, 15, 20);
        getContentPane().setBackground(new Color(245, 245, 250)); // very light gray-blue background

        JButton studentButton = new JButton("Student");
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(studentButton, gbc);
        studentButton.setBackground(new Color(207, 161, 250)); // cornflower blue
        studentButton.setForeground(Color.WHITE);
        studentButton.setFocusPainted(false);
        studentButton.setFont(new Font("Arial", Font.BOLD, 16));
        studentButton.setPreferredSize(new Dimension(150, 30));

        JButton employeeButton = new JButton("Employee");
        gbc.gridy = 1;
        add(employeeButton, gbc);
        employeeButton.setBackground(new Color(255, 214, 23)); // medium sea green
        employeeButton.setForeground(Color.WHITE);
        employeeButton.setFocusPainted(false);
        employeeButton.setFont(new Font("Arial", Font.BOLD, 16));
        employeeButton.setPreferredSize(new Dimension(150, 30));

        studentButton.addActionListener(e -> {
            new StudentPage();
            dispose();
        });

        employeeButton.addActionListener(e -> {
            new EmployeePage();
            dispose();
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }
}
